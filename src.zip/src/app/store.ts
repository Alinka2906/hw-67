import {configureStore} from '@reduxjs/toolkit';
import {doorCodReducer} from '../containers/DoorCode/DoorCodeSlice';

export const store = configureStore({
  reducer: {
    doorCode: doorCodReducer,
  }
});

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;