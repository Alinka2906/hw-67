import React from 'react';
import DoorCode from './containers/DoorCode/DoorCode';
import './App.css';


function App() {
  return (
    <div className="App">
     <DoorCode/>
    </div>
  );
}

export default App;
