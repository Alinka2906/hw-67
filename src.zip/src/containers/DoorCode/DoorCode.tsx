import React from 'react';
import './DoorCode.css';
import {useDispatch, useSelector} from 'react-redux';
import {RootState} from '../../app/store';
import {one, two, increaseBy, decreaseBy} from './DoorCodeSlice';

const DoorCode = () => {
  const dispatch = useDispatch();
  const doorCodeValue = useSelector((state: RootState) => state.doorCode.value);


  return (
    <div className="doorCode">
      <div className='doorDisplay'>
        <h1>{doorCodeValue}{doorCodeValue}{doorCodeValue}{doorCodeValue}</h1>
      </div>
      <div className='doorButton'>
        <button className='btn' onClick={() => dispatch(one())}>1</button>
        <button className='btn' onClick={() => dispatch(two())}>2</button>
        <button className='btn' onClick={() => dispatch(increaseBy(3))}>3</button>
        <button className='btn' onClick={() => dispatch(increaseBy(4))}>4</button>
        <button className='btn' onClick={() => dispatch(increaseBy(5))}>5</button>
        <button className='btn' onClick={() => dispatch(increaseBy(6))}>6</button>
        <button className='btn' onClick={() => dispatch(increaseBy(7))}>7</button>
        <button className='btn' onClick={() => dispatch(increaseBy(5))}>8</button>
        <button className='btn' onClick={() => dispatch(increaseBy(5))}>9</button>
        <button className='btn' onClick={() => dispatch(increaseBy(5))}>del</button>
        <button className='btn' onClick={() => dispatch(increaseBy(5))}>0</button>
        <button className='btn' onClick={() => dispatch(increaseBy(5))}>E</button>
      </div>
    </div>

  );
}

export default DoorCode;