import {createSlice, PayloadAction} from '@reduxjs/toolkit';

interface DoorCodeState {
  value: number;
}

const initialState: DoorCodeState = {
  value: 0
};

export const doorCodeSlice = createSlice({
  name: 'doorCode',
  initialState,
  reducers: {
    one: (state) => {
      state.value = 1;
    },
    two: (state) => {
      state.value = 2;
    },
    increaseBy: (state, action: PayloadAction<number>) => {
      state.value += action.payload;
    },
    decreaseBy: (state, action: PayloadAction<number>) => {
      state.value -= action.payload;
    }
  }
});

export const doorCodReducer = doorCodeSlice.reducer;
export const {one, two, increaseBy, decreaseBy} = doorCodeSlice.actions;


